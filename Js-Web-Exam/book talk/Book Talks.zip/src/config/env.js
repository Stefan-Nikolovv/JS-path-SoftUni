exports.connectionLink = 'mongodb://localhost:27017/bookTalks';

exports.Salt_Rounds = 10;

exports.SECRET = '6ddfd9d54a491e9a39f038e8b0d14a01'